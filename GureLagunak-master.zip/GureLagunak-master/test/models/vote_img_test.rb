require 'test_helper'

class VoteImgTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
