require 'test_helper'

class VoteCommTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
