class Comment < ApplicationRecord
	belongs_to :user
	belongs_to :image
	
	has_many :vote_imgs, dependent: :delete_all
    has_many :vote_comms, dependent: :delete_all
end
