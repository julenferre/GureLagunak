module VoteCommsHelper
end
