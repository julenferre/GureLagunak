module VoteImgsHelper
end
